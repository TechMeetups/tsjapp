(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/j4507_datatables-bootstrap-3/packages/j4507_datatables-b //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['j4507:datatables-bootstrap-3'] = {};

})();

//# sourceMappingURL=j4507_datatables-bootstrap-3.js.map
