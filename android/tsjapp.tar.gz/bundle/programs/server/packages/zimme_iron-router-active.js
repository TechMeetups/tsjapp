(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var ActiveRoute = Package['zimme:active-route'].ActiveRoute;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/zimme_iron-router-active/packages/zimme_iron-router-acti //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['zimme:iron-router-active'] = {};

})();

//# sourceMappingURL=zimme_iron-router-active.js.map
