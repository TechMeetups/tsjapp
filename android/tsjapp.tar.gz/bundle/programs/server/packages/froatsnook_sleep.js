(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/froatsnook_sleep/server/sleep.js                         //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
var asyncSleep = function(ms, callback) {                            // 1
    Meteor.setTimeout(function() {                                   // 2
        callback(null);                                              // 3
    }, ms);                                                          // 4
};                                                                   // 5
                                                                     // 6
var asyncSleepUntil = function(date, callback) {                     // 7
    if (typeof date === "function") {                                // 8
        throw new Error("Missing parameter `date'");                 // 9
    }                                                                // 10
                                                                     // 11
    var now = Date.now();                                            // 12
    var then = +date;                                                // 13
    var ms = Math.max(0, then - now);                                // 14
    asyncSleep(ms, callback);                                        // 15
};                                                                   // 16
                                                                     // 17
if (typeof Meteor.wrapAsync !== "undefined") {                       // 18
    Meteor.sleep = Meteor.wrapAsync(asyncSleep);                     // 19
    Meteor.sleepUntil = Meteor.wrapAsync(asyncSleepUntil);           // 20
} else {                                                             // 21
    Meteor.sleep = Meteor._wrapAsync(asyncSleep);                    // 22
    Meteor.sleepUntil = Meteor._wrapAsync(asyncSleepUntil);          // 23
}                                                                    // 24
                                                                     // 25
                                                                     // 26
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['froatsnook:sleep'] = {};

})();

//# sourceMappingURL=froatsnook_sleep.js.map
