(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Busboy;

(function(){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/shammar13_busboy/packages/shammar13_busboy.js                 //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
(function () {                                                            // 1
                                                                          // 2
///////////////////////////////////////////////////////////////////////   // 3
//                                                                   //   // 4
// packages/shammar13:busboy/busboy.js                               //   // 5
//                                                                   //   // 6
///////////////////////////////////////////////////////////////////////   // 7
                                                                     //   // 8
Busboy = Npm.require('busboy');                                      // 1
                                                                     // 2
///////////////////////////////////////////////////////////////////////   // 11
                                                                          // 12
}).call(this);                                                            // 13
                                                                          // 14
////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['shammar13:busboy'] = {
  Busboy: Busboy
};

})();

//# sourceMappingURL=shammar13_busboy.js.map
