(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var Blaze = Package.blaze.Blaze;
var UI = Package.blaze.UI;
var Handlebars = Package.blaze.Handlebars;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var Hammer;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/chriswessels_hammer/packages/chriswessels_hammer.js      //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['chriswessels:hammer'] = {
  Hammer: Hammer
};

})();

//# sourceMappingURL=chriswessels_hammer.js.map
